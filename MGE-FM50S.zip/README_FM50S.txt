README.txt — MIB do Transmissor FM50S
=====================================

📌 Descrição Geral
------------------
Este arquivo `FM50S.mib` define a MIB (Management Information Base) personalizada para o transmissor FM50S,
desenvolvido pela MGE Broadcast. O objetivo da MIB é fornecer informações estruturadas via SNMP sobre
medições elétricas, status do dispositivo, alarmes e comandos remotos.

📁 Estrutura da MIB
-------------------
A MIB está organizada em grupos hierárquicos, baseados no prefixo `myDevice`, contendo:

| Bloco                | OID base             | Conteúdo                                                   |
|---------------------|----------------------|------------------------------------------------------------|
| DeviceInfo          | myDevice.1           | Modelo, número de série e dados fixos do equipamento       |
| DeviceObjects       | myDevice.2           | Agrupamento geral de sensores                              |
| TelemetryMeasurements | myDevice.3         | Medições de corrente, tensão, rejeição, falhas, etc.       |

🧠 Padrões de nomeação
----------------------
- Nomes em snake_case para consistência (`pa_current_a`, `total_pa_current`, etc).
- Medições usam tipo `Gauge32`, apropriado para valores variáveis.
- Campos com valores estáticos como nome ou modelo usam `DisplayString`.

📐 Tipos SNMP utilizados
------------------------
| Tipo SNMP       | Aplicação                                      |
|------------------|------------------------------------------------|
| Gauge32         | Tensões, correntes, potências, eficiências     |
| DisplayString   | Texto fixo como nome, modelo, número de série  |
| INTEGER (enum)  | Comandos tipo botão (ex: reset, power)         |

🚦 MAX-ACCESS — Acessibilidade dos objetos
------------------------------------------
| Valor             | Quando usar                                       |
|-------------------|---------------------------------------------------|
| read-only         | Para sensores, status, alarmes                    |
| read-write        | Para comandos de botão ou configurações remotas  |
| not-accessible    | Usado internamente em `OBJECT IDENTIFIER`        |

⚠️ Pontos de Atenção
---------------------
1. Organização dos OIDs:
   Os caminhos SNMP estão organizados como `{ TelemetryMeasurements 1 X Y }` onde:
   - X indica a categoria (ex: falhas, rejeição, corrente, etc)
   - Y é o índice do item dentro do grupo

2. Extensão .mib:
   Certifique-se de que o arquivo esteja salvo como `.mib` para ser reconhecido por gerenciadores SNMP
   como iReasoning, Paessler, Net-SNMP, etc.

3. Compilação:
   Teste o carregamento da MIB no seu gerenciador SNMP para validar a sintaxe.
   Ferramentas como `snmptranslate` (Net-SNMP) ajudam a verificar a estrutura da árvore.

4. Uso de comandos (botões):
   Objetos como `reset_device` devem ser enviados via SNMP SET com valores documentados (1 para reset, por exemplo).

5. Unidades:
   O campo UNITS foi adicionado para facilitar a exibição nos managers, mas não é interpretado automaticamente
   por todos os SNMP tools.

📤 Contato
----------
- Organização: MGE Broadcast
- E-mail: mge@mgebr.com.br
- Última atualização: 15/07/2025
